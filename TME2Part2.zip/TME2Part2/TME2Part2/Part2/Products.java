/**
 * This TME aims to familiarize students with Java generics features.
 * Part 2: (35%)
 * 8. Design and implement a subclass of GenericOrder called ComputerPartyOrder that takes an arbitrary number of different classes of ComputerPart objects, 
 * Peripheral objects, Cheese objects, Fruit objects and Service objects
 * 9. Create another client class that creates ComputerPartyOrder. Modify OrderProcessor if necessary.
 * 10. Pack the above codes into a second zip file and send it to your tutor.
 */

/** 
 *             TME2, COMP308
 * Class:      Products.java
 * Purpose:    The below program will mainly use JAVA generic container and relevant methods
 *             to simulate customer orders.
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       December 20, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */
package Part2;

import java.util.*;

/**
 * The Product class, along with every subclass was provided by the source noted
 * above, however, I did modify these classes slightly by adding an ID field in
 * order to associate each product with the order ID individually.
 */
abstract class Product {
	protected float price;
	protected String ID;

// return the price of a particular product
	abstract float price();

// return the order ID of a particular product
	abstract String ID();
}

//------------------------------------------------------------

class ComputerPart extends Product {
	public ComputerPart(String orderID, float p) {
		price = p;
		ID = orderID;
	}

	public float price() {
		return price;
	}

	public String ID() {
		return ID;
	}
}

class Motherboard extends ComputerPart {
	protected String manufacturer;

	public Motherboard(String ID, String mfg, float p) {
		super(ID, p);
		manufacturer = mfg;
	}

	public String getManufacturer() {
		return manufacturer;
	}
}

class RAM extends ComputerPart {
	protected int size;
	protected String manufacturer;

	public RAM(String ID, String mfg, int size, float p) {
		super(ID, p);
		this.manufacturer = mfg;
		this.size = size;
	}

	public String getManufacturer() {
		return manufacturer;
	}
}

class Drive extends ComputerPart {
	protected String type;
	protected int speed;

	public Drive(String ID, String type, int speed, float p) {
		super(ID, p);
		this.type = type;
		this.speed = speed;
	}

	public String getType() {
		return type;
	}

	public int getSpeed() {
		return speed;
	}
}

class Peripheral extends Product {
	public Peripheral(String orderID, float p) {
		ID = orderID;
		price = p;
	}

	public float price() {
		return price;
	}

	public String ID() {
		return ID;
	}
}

class Printer extends Peripheral {
	protected String model;

	public Printer(String ID, String model, float p) {
		super(ID, p);
		this.model = model;
	}

	public String getModel() {
		return model;
	}
}

class Monitor extends Peripheral {
	protected String model;

	public Monitor(String ID, String model, float p) {
		super(ID, p);
		this.model = model;
	}

	public String getModel() {
		return model;
	}
}

class Service extends Product {
	public Service(String orderID, float p) {
		price = p;
		ID = orderID;
	}

	public float price() {
		return price;
	}

	public String ID() {
		return ID;
	}
}

class AssemblyService extends Service {
	String provider;

	public AssemblyService(String ID, String pv, float p) {
		super(ID, p);
		provider = pv;
	}

	public String getProvider() {
		return provider;
	}
}

class DeliveryService extends Service {
	String courier;

	public DeliveryService(String ID, String c, float p) {
		super(ID, p);
		courier = c;
	}

	public String getCourier() {
		return courier;
	}
}

//-------------------------------------------------------
class Cheese extends Product {
	public Cheese(String orderID, float p) {
		price = p;
		ID = orderID;
	}

	public float price() {
		return price;
	}

	public String ID() {
		return ID;
	}
}

class Cheddar extends Cheese {
	public Cheddar(String ID, float p) {
		super(ID, p);
	}
}

class Mozzarella extends Cheese {
	public Mozzarella(String ID, float p) {
		super(ID, p);
	}
}

class Fruit extends Product {
	public Fruit(String orderID, float p) {
		price = p;
		ID = orderID;
	}

	public float price() {
		return price;
	}

	public String ID() {
		return ID;
	}
}

class Apple extends Fruit {
	public Apple(String ID, float p) {
		super(ID, p);
	}
}

class Orange extends Fruit {
	public Orange(String ID, float p) {
		super(ID, p);
	}
}

//-------------------------------------------------------
/**
 * Products class, used to hold the main method which calls the client class to
 * test OrderProcessor functionality
 */
public class Products {
	public static void main(String[] args) {
		ClientTest.testOrder();
		ClientTest2.testOrder();
	}
}

//-------------------------------------------------------
//GenericOrder acts as a collection of an arbitrary nnumber of Product types:
class GenericOrder {
	public ArrayList<Product> order; // field to hold the ArrayList of Products (the order)
	public String ID; // field to hold the order ID

//GenericOrder constructor:
	public GenericOrder(String ID) {
		ArrayList<Product> order = new ArrayList<Product>(0); // creates an initial ArrayList of Products with a size of
																// 0 (to be added to)
		this.order = order; // sets the order field to be the created ArrayList, upon the creation of a
							// GenericOrder
		this.ID = ID; // sets the ID field to be the sent in ID, upon the creation of a GenericOrder
	}

//Generic class since several subclasses of Product can be added to the order:
	public <T extends Product> void add(T item) {
		order.add(item); // adds item to order ArrayList
	}

	public Product get(int element) {
		return order.get(element); // gets the element of the order as sent in numerically
	}

	public String getID() {
		return ID; // returns the order ID
	}

	public int size() {
		return order.size(); // returns the size of the order
	}
}

//-----------------------------------------------------------------------------------------------------------

//ComputerPartyOrder extends GenericOrder, and can accept all types of Products(from each category):
class ComputerPartyOrder extends GenericOrder {
//ComputerPartyOrder constructor:
	public ComputerPartyOrder(String ID) {
		super(ID); // calls the superclass
	}
}

//-----------------------------------------------------------------------------------------------------------

//ComputerOrder extends GenericOrder, however it can only accept specific types of Products:
class ComputerOrder extends GenericOrder {
//ComputerOrder constructor:
	public ComputerOrder(String ID) {
		super(ID); // calls the superclass
	}

	public void add(Product item) {
//overrides the add method in the superclass to only add the correct types of Product to the ComputerOrder:
		if (item.getClass().getSuperclass().equals(ComputerPart.class)
				|| item.getClass().getSuperclass().equals(Peripheral.class)
				|| item.getClass().getSuperclass().equals(Service.class)) {
			order.add(item);
		} else {
//if an incorrect item is attempted to be added, this error message is printed and the item is not added:
			System.out.println(
					"The item you are trying to purchase does not fit within the order type and cannot be added.");
		}
	}
}

//-----------------------------------------------------------------------------------------------------------

//PartyTrayOrder extends GenericOrder, however it can only accept specific types of Products:
class PartyTrayOrder extends GenericOrder {
//PartyTrayOrder constructor:
	public PartyTrayOrder(String ID) {
		super(ID); // calls the superclass
	}

	public void add(Product item) {
//overrides the add method in the superclass to only add the correct types of Product to the PartyTrayOrder:
		if (item.getClass().getSuperclass().equals(Cheese.class) || item.getClass().getSuperclass().equals(Fruit.class)
				|| item.getClass().getSuperclass().equals(Service.class)) {
			order.add(item);
		} else {
//if an incorrect item is attempted to be added, this error message is printed and the item is not added:
			System.out.println(
					"The item you are trying to purchase does not fit within the order type and cannot be added.");
		}
	}
}

//-----------------------------------------------------------------------------------------------------------

//OrderProcessor uses a variety of organization methods to process and dispatch multiple orders
class OrderProcessor {
	public ArrayList<GenericOrder> orderList; // field to hold the ArrayList of orders that are accepted

//OrderProcessor constructor:
	public OrderProcessor() {
		ArrayList<GenericOrder> orderList = new ArrayList<GenericOrder>(0); // creates an initial ArrayList of
																			// GenericOrder type with a size of 0 (to be
																			// added to)
		this.orderList = orderList; // sets the orderList field to be the created ArrayList, upon the creation of an
									// OrderProcessor
	}

	public <T extends GenericOrder> void accept(T order) {
		orderList.add(order); // adds item to order ArrayList
	}

	public ArrayList<GenericOrder> get() {
		return orderList; // returns the orderList ArrayList to be sent for further processing
	}

//the process method taked in all accepted orders and sorts them into more specific collections:
	public static void process(ArrayList<GenericOrder> orderList) {
//ArrayLists to hold the sorted collections:
		ArrayList<Product> computerList = new ArrayList<Product>();
		ArrayList<Product> peripheralList = new ArrayList<Product>();
		ArrayList<Product> cheeseList = new ArrayList<Product>();
		ArrayList<Product> fruitList = new ArrayList<Product>();
		ArrayList<Product> serviceList = new ArrayList<Product>();

//for each order in orderList, each Product in the order is type checked and sorted accordingly:
		for (int i = 0; i < orderList.size(); i++) {
			for (int j = 0; j < orderList.get(i).size(); j++) {
				if (orderList.get(i).get(j).getClass().getSuperclass().equals(ComputerPart.class)) {
					computerList.add(orderList.get(i).get(j));
				} else if (orderList.get(i).get(j).getClass().getSuperclass().equals(Peripheral.class)) {
					peripheralList.add(orderList.get(i).get(j));
				} else if (orderList.get(i).get(j).getClass().getSuperclass().equals(Cheese.class)) {
					cheeseList.add(orderList.get(i).get(j));
				} else if (orderList.get(i).get(j).getClass().getSuperclass().equals(Fruit.class)) {
					fruitList.add(orderList.get(i).get(j));
				} else if (orderList.get(i).get(j).getClass().getSuperclass().equals(Service.class)) {
					serviceList.add(orderList.get(i).get(j));
				}
			}
		}

//dispatching the orders to the appropriate dispatch methods:
		dispatchComputerParts(computerList);
		dispatchPeripherals(peripheralList);
		dispatchCheeses(cheeseList);
		dispatchFruits(fruitList);
		dispatchServices(serviceList);
	}

//Each dispatchXXX method produces output based on the type of items within the collection to be dispatched after type checking through instanceof:

	public static void dispatchComputerParts(ArrayList<Product> order) {
		for (int i = 0; i < order.size(); i++) {
			if (order.get(i) instanceof Motherboard) {
				Motherboard temp = (Motherboard) order.get(i);
				System.out.println("Motherboard manufacturer = " + temp.manufacturer + ", price = $" + temp.price
						+ ", order number = " + temp.ID);
			}
		}

		for (int i = 0; i < order.size(); i++) {
			if (order.get(i) instanceof RAM) {
				RAM temp = (RAM) order.get(i);
				System.out.println("RAM manufacturer = " + temp.manufacturer + ", size = " + temp.size + "GB, price = $"
						+ temp.price + ", order number = " + temp.ID);
			}
		}

		for (int i = 0; i < order.size(); i++) {
			if (order.get(i) instanceof Drive) {
				Drive temp = (Drive) order.get(i);
				System.out.println("Drive type = " + temp.type + ", speed = " + temp.speed + "MB/s, price = $"
						+ temp.price + ", order number = " + temp.ID);
			}
		}
	}

	public static void dispatchPeripherals(ArrayList<Product> order) {
		for (int i = 0; i < order.size(); i++) {
			if (order.get(i) instanceof Printer) {
				Printer temp = (Printer) order.get(i);
				System.out.println(
						"Printer model = " + temp.model + ", price = $" + temp.price + ", order number = " + temp.ID);
			}
		}

		for (int i = 0; i < order.size(); i++) {
			if (order.get(i) instanceof Monitor) {
				Monitor temp = (Monitor) order.get(i);
				System.out.println(
						"Monitor model = " + temp.model + ", price = $" + temp.price + ", order number = " + temp.ID);
			}
		}
	}

	public static void dispatchCheeses(ArrayList<Product> order) {
		for (int i = 0; i < order.size(); i++) {
			if (order.get(i) instanceof Cheddar) {
				Cheddar temp = (Cheddar) order.get(i);
				System.out.println("Cheddar price = $" + temp.price + ", order number = " + temp.ID);
			}
		}

		for (int i = 0; i < order.size(); i++) {
			if (order.get(i) instanceof Mozzarella) {
				Mozzarella temp = (Mozzarella) order.get(i);
				System.out.println("Mozzarella price = $" + temp.price + ", order number = " + temp.ID);
			}
		}

	}

	public static void dispatchFruits(ArrayList<Product> order) {
		for (int i = 0; i < order.size(); i++) {
			if (order.get(i) instanceof Apple) {
				Apple temp = (Apple) order.get(i);
				System.out.println("Apple price = $" + temp.price + ", order number = " + temp.ID);
			}
		}

		for (int i = 0; i < order.size(); i++) {
			if (order.get(i) instanceof Orange) {
				Orange temp = (Orange) order.get(i);
				System.out.println("Orange price = $" + temp.price + ", order number = " + temp.ID);
			}
		}
	}

	public static void dispatchServices(ArrayList<Product> order) {
		for (int i = 0; i < order.size(); i++) {
			if (order.get(i) instanceof AssemblyService) {
				AssemblyService temp = (AssemblyService) order.get(i);
				System.out.println("Assembly Service Provider = " + temp.provider + ", price = $" + temp.price
						+ ", order number = " + temp.ID);
			}
		}

		for (int i = 0; i < order.size(); i++) {
			if (order.get(i) instanceof DeliveryService) {
				DeliveryService temp = (DeliveryService) order.get(i);
				System.out.println("Delivery Service Courier = " + temp.courier + ", price = $" + temp.price
						+ ", order number = " + temp.ID);
			}
		}
	}
}

//-----------------------------------------------------------------------------------------------------------

//client class to test OrderProcessor:
class ClientTest {
	public static void testOrder() {
//generating an OrderProcessor which will be used for output later:
		OrderProcessor orderList = new OrderProcessor();

//generating a random number of each type of order:
		int genNum = randInt(1, 3);
		int compNum = randInt(1, 3);
		int partyNum = randInt(1, 3);

//Testing:
		System.out.println("Test Values for Client Test 1:");
		System.out.println("Number of Generic Orders: " + genNum);
		System.out.println("Number of Computer Part Orders: " + compNum);
		System.out.println("Number of Party Orders: " + partyNum);

//generating a random number of products to be held by each type of order:
		int genItemNum = randInt(1, 10);
		int compItemNum = randInt(1, 10);
		int partyItemNum = randInt(1, 10);

		int orders = 0; // variable to track how many orders have been created

		int prodNum = 0; // Used for testing to see which Products are generated (by the random)

		/**
		 * generating at least one of each type of order, with a corresponding order ID
		 * number. For each order, the randomly generated number of products are created
		 * and added to each order: Note: In my case, I put constraints on the types of
		 * items that will be added to the order by using bounds for the randomly chosen
		 * Product types here. My test plans explain this further, as well as
		 * alterations to this that could include incorrect Product types attempting to
		 * be added to specific orders.
		 */
		for (int i = orders; i < genNum; i++) {
			int itemNum = randInt(1, 10); // generating a random number of products to be held by each type of order
			int orderNum = i + 1;
			orders = orderNum; // keeping track of how many orders have been created

			System.out.println("\nOrder Number: " + orderNum + ", Number of Items: " + itemNum); // Used for Testing

			GenericOrder genOrder = new GenericOrder("Order " + orderNum);

			for (int j = 0; j < itemNum; j++) {
				prodNum = randInt(0, 10); // generating a random Product type to be added to the order
				genOrder.add(productGenerator(genOrder.ID, prodNum));
				System.out.println("Order ID: " + genOrder.ID + ", Product Type Generated: " + prodNum);
			}

			orderList.accept(genOrder);
		}

		compNum = compNum + orders;

		for (int i = orders; i < compNum; i++) {
			int itemNum = randInt(1, 10); // generating a random number of products to be held by each type of order
			int orderNum = i + 1;
			orders = orderNum;

			System.out.println("\nOrder Number: " + orderNum + ", Number of Items: " + itemNum); // Used for Testing

			ComputerOrder compOrder = new ComputerOrder("Order " + orderNum);

			for (int j = 0; j < itemNum; j++) {
				prodNum = randInt(0, 6); // generating a random Product type to be added to the order
				compOrder.add(productGenerator(compOrder.ID, prodNum));
				System.out.println("Order ID: " + compOrder.ID + ", Product Type Generated: " + prodNum);
			}

			orderList.accept(compOrder);
		}

		partyNum = partyNum + orders;

		for (int i = orders; i < partyNum; i++) {
			int itemNum = randInt(1, 10); // generating a random number of products to be held by each type of order
			int orderNum = i + 1;
			orders = orderNum;

			System.out.println("\nOrder Number: " + orderNum + ", Number of Items: " + itemNum); // Used for Testing

			PartyTrayOrder partyOrder = new PartyTrayOrder("Order " + orderNum);

			for (int j = 0; j < itemNum; j++) {
				prodNum = randInt(5, 10); // generating a random Product type to be added to the order
				partyOrder.add(productGenerator(partyOrder.ID, prodNum));
				System.out.println("Order ID: " + partyOrder.ID + ", Product Type Generated: " + prodNum);
			}

			orderList.accept(partyOrder);
		}

		System.out.println("\nClient Test 1 List of Sorted Orders:");
		OrderProcessor.process(orderList.get()); // processing the order (as well as dispatching, since dispatch methods
													// are called by process method)
	}

//generates a Product of random type, depending on the number sent in, while also assigning order IDs to each Product:
	public static Product productGenerator(String ID, int prodNum) {
		if (prodNum == 0) {
			Motherboard item = new Motherboard(ID, randManufacturer(randInt(0, 3)), randFloat(100, 200));
			return (item);
		} else if (prodNum == 1) {
			RAM item = new RAM(ID, randManufacturer(randInt(0, 3)), randSize(randInt(0, 4)), randFloat(100, 200));
			return (item);
		} else if (prodNum == 2) {
			Drive item = new Drive(ID, randDrive(randInt(0, 1)), randSpeed(randInt(0, 3)), randFloat(100, 200));
			return (item);
		} else if (prodNum == 3) {
			Printer item = new Printer(ID, randPrinter(randInt(0, 4)), randFloat(70, 300));
			return (item);
		} else if (prodNum == 4) {
			Monitor item = new Monitor(ID, randMonitor(randInt(0, 4)), randFloat(100, 300));
			return (item);
		} else if (prodNum == 5) {
			AssemblyService item = new AssemblyService(ID, randProvider(randInt(0, 1)), randFloat(29, 79));
			return (item);
		} else if (prodNum == 6) {
			DeliveryService item = new DeliveryService(ID, randCourier(randInt(0, 2)), randFloat(4, 24));
			return (item);
		} else if (prodNum == 7) {
			Cheddar item = new Cheddar(ID, randFloat(3, 16));
			return (item);
		} else if (prodNum == 8) {
			Mozzarella item = new Mozzarella(ID, randFloat(3, 16));
			return (item);
		} else if (prodNum == 9) {
			Apple item = new Apple(ID, randFloat(0, 6));
			return (item);
		} else {
			Orange item = new Orange(ID, randFloat(0, 4));
			return (item);
		}
	}

//generates random integer based on range of numbers sent in:
	public static int randInt(int min, int max) {
		Random randGen = new Random();
		int rand = 0;
		if (min == max) {
			rand = min;
		} else if (min > max) {
			System.out.println("Invalid range to create random. Max must be greater than or equal to min.");
		} else {
			rand = randGen.nextInt(max - min + 1) + min;
		}
		return rand;
	}

//generates random float ending in .99 (for price) based on range of numbers sent in:
	public static float randFloat(int min, int max) {
		Random randGen = new Random();
		int randInteger = 0;
		float rand = 0;
		if (min == max) {
			randInteger = min;
		} else if (min > max) {
			System.out.println("Invalid range to create random. Max must be greater than or equal to min.");
		} else {
			randInteger = randGen.nextInt(max - min) + min;
		}
		rand = randInteger + 0.99f;
		return rand;
	}

	/**
	 * the following methods help generate more random characteristics for each type
	 * of generated Product, using switch statements and a random number sent in to
	 * the method:
	 */

	public static String randManufacturer(int type) {
		String manufacturer = null;
		switch (type) {
		case 0:
			manufacturer = "Asus";
			break;
		case 1:
			manufacturer = "IBM";
			break;
		case 2:
			manufacturer = "Foxconn";
			break;
		case 3:
			manufacturer = "Lenovo";
			break;
		default:
			System.out.println("Invalid Manufacturer Type"); // Error in case a number is sent in that is out of the
																// bounds
			break;
		}
		return manufacturer; // returning randomly chosen characteristic for Product creation
	}

	public static String randDrive(int type) {
		String drive = null;
		switch (type) {
		case 0:
			drive = "HDD";
			break;
		case 1:
			drive = "SSD";
			break;
		default:
			System.out.println("Invalid Drive Type");
			break;
		}
		return drive;
	}

	public static String randPrinter(int type) {
		String printer = null;
		switch (type) {
		case 0:
			printer = "Brother";
			break;
		case 1:
			printer = "Canon";
			break;
		case 2:
			printer = "Dell";
			break;
		case 3:
			printer = "Epson";
			break;
		case 4:
			printer = "Lexmark";
			break;
		default:
			System.out.println("Invalid Printer Type");
			break;
		}
		return printer;
	}

	public static String randMonitor(int type) {
		String monitor = null;
		switch (type) {
		case 0:
			monitor = "Acer";
			break;
		case 1:
			monitor = "Dell";
			break;
		case 2:
			monitor = "Foxconn";
			break;
		case 3:
			monitor = "Compaq";
			break;
		case 4:
			monitor = "HP";
			break;
		default:
			System.out.println("Invalid Monitor Type");
			break;
		}
		return monitor;
	}

	public static String randProvider(int type) {
		String provider = null;
		switch (type) {
		case 0:
			provider = "Apollo Assembly";
			break;
		case 1:
			provider = "We Build";
			break;
		default:
			System.out.println("Invalid Provider Type");
			break;
		}
		return provider;
	}

	public static String randCourier(int type) {
		String courier = null;
		switch (type) {
		case 0:
			courier = "Canada Post";
			break;
		case 1:
			courier = "UPS";
			break;
		case 2:
			courier = "FedEx";
			break;
		default:
			System.out.println("Invalid Courier Type");
			break;
		}
		return courier;
	}

	public static int randSize(int type) {
		int size = 0;
		switch (type) {
		case 0:
			size = 2;
			break;
		case 1:
			size = 4;
			break;
		case 2:
			size = 8;
			break;
		case 3:
			size = 12;
			break;
		case 4:
			size = 16;
			break;
		default:
			System.out.println("Invalid Drive Size");
			break;
		}
		return size;
	}

	public static int randSpeed(int type) {
		int speed = 0;
		switch (type) {
		case 0:
			speed = 50;
			break;
		case 1:
			speed = 120;
			break;
		case 2:
			speed = 200;
			break;
		case 3:
			speed = 550;
			break;
		default:
			System.out.println("Invalid Speed");
			break;
		}
		return speed;
	}
}

//-----------------------------------------------------------------------------------------------------------

class ClientTest2 extends ClientTest {
	public static void testOrder() {
//generating an OrderProcessor which will be used for output later:
		OrderProcessor orderList = new OrderProcessor();

//generating a random number of each type of order:
		int genNum = randInt(1, 3);
		int compNum = randInt(1, 3);
		int partyNum = randInt(1, 3);
		int compPartyNum = randInt(1, 3);

//Testing:
		System.out.println("\nTest Values for Client Test 2:");
		System.out.println("Number of Generic Orders: " + genNum);
		System.out.println("Number of Computer Part Orders: " + compNum);
		System.out.println("Number of Party Orders: " + partyNum);
		System.out.println("Number of Computer Part Party Orders: " + compPartyNum);

		int orders = 0; // variable to track how many orders have been created

		int prodNum = 0; // Used for testing to see which Products are generated (by the random)

		/**
		 * generating at least one of each type of order, with a corresponding order ID
		 * number. For each order, the randomly generated number of products are created
		 * and added to each order: Note: In my case, I put constraints on the types of
		 * items that will be added to the order by using bounds for the randomly chosen
		 * Product types here. My test plans explain this further, as well as
		 * alterations to this that could include incorrect Product types attempting to
		 * be added to specific orders.
		 */
		for (int i = orders; i < genNum; i++) {
			int itemNum = randInt(1, 10); // generating a random number of products to be held by each type of order
			int orderNum = i + 1;
			orders = orderNum; // keeping track of how many orders have been created

			System.out.println("\nOrder Number: " + orderNum + ", Number of Items: " + itemNum); // Used for Testing

			GenericOrder genOrder = new GenericOrder("Order " + orderNum);

			for (int j = 0; j < itemNum; j++) {
				prodNum = randInt(0, 10); // generating a random Product type to be added to the order
				genOrder.add(productGenerator(genOrder.ID, prodNum));
				System.out.println("Order ID: " + genOrder.ID + ", Product Type Generated: " + prodNum);
			}

			orderList.accept(genOrder);
		}

		compPartyNum = compPartyNum + orders;

		for (int i = orders; i < compPartyNum; i++) {
			int itemNum = randInt(1, 10);
			int orderNum = i + 1;
			orders = orderNum; // keeping track of how many orders have been created

			System.out.println("\nOrder Number: " + orderNum + ", Number of Items: " + itemNum); // Used for Testing

			ComputerPartyOrder compPartyOrder = new ComputerPartyOrder("Order " + orderNum);

			for (int j = 0; j < itemNum; j++) {
				prodNum = randInt(0, 10); // generating a random Product type to be added to the order
				compPartyOrder.add(productGenerator(compPartyOrder.ID, prodNum));
				System.out.println("Order ID: " + compPartyOrder.ID + ", Product Type Generated: " + prodNum);
			}

			orderList.accept(compPartyOrder);
		}

		compNum = compNum + orders;

		for (int i = orders; i < compNum; i++) {
			int itemNum = randInt(1, 10);
			int orderNum = i + 1;
			orders = orderNum;

			System.out.println("\nOrder Number: " + orderNum + ", Number of Items: " + itemNum); // Used for Testing

			ComputerOrder compOrder = new ComputerOrder("Order " + orderNum);

			for (int j = 0; j < itemNum; j++) {
				prodNum = randInt(0, 6); // generating a random Product type to be added to the order
				compOrder.add(productGenerator(compOrder.ID, prodNum));
				System.out.println("Order ID: " + compOrder.ID + ", Product Type Generated: " + prodNum);
			}

			orderList.accept(compOrder);
		}

		partyNum = partyNum + orders;

		for (int i = orders; i < partyNum; i++) {
			int itemNum = randInt(1, 10);
			int orderNum = i + 1;
			orders = orderNum;

			System.out.println("\nOrder Number: " + orderNum + " Number of Items: " + itemNum); // Used for Testing

			PartyTrayOrder partyOrder = new PartyTrayOrder("Order " + orderNum);

			for (int j = 0; j < itemNum; j++) {
				prodNum = randInt(5, 10); // generating a random Product type to be added to the order
				partyOrder.add(productGenerator(partyOrder.ID, prodNum));
				System.out.println("Order ID: " + partyOrder.ID + ", Product Type Generated: " + prodNum);
			}

			orderList.accept(partyOrder);
		}

		System.out.println("\nClient Test 2 List of Sorted Orders:");
		OrderProcessor.process(orderList.get()); // processing the order (as well as dispatching, since dispatch methods
													// are called by process method)
	}
}

