/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */
package tme3;


/**
 * 
 *  <p> class that checks light on or off and show message </p>
 *
 */

public class LightOff extends Event {
    private static final long serialVersionUID = 1L;

    public LightOff(Controller ctl, long delayTime) {
        super(ctl, delayTime);
    }

    public void action() {
        // Put hardware control code here to
        // physically turn on the light.
        ctl.setVariable("light", false);
    }

    public String toString() {
        return "Light is off";
    }
}
