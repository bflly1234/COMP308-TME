/**
 * 1. Make Event implements Runnable so that each type of event provides its own timing. 
 * Each event file should be a class of its own. Change the rest of the design to simplify this model.
 * 2. Provide the means to create the event classes from their names (see the Constructor class in java.lang.reflect 
 * and getConstructor() in the Class Class). Use the same capability to be able to 
 * add new Event classes and modify Event classes without recompiling GreenhouseControls.java 
 * (remove all the classes as inner classes and make them public classes in their own file). 
 * Start the Event thread right after you have successfully created the Event object. Make whatever changes are required to the overall design.
 * 3. Events should be started once they are created. Devise a mechanism for GreenhouseControls to suspend and resume the Event threads. 
 * To do this GreenhouseControls needs to keep a collection of threads of all events.
 * 4. Remove all existing states variables in GreenhouseControls and replace them by using a collection of TwoTuple (See examples in TIJ pages 621 to 624). 
 * Each time an event runs it should add an entry that identifies the variable the event is modifying as key, 
 * and another object to this structure as the value the event is setting. Create a method in GreenhouseControls called setVariable to handle updating to this collection. 
 * Use the synchronization feature in java to ensure that two Event classes are not trying to add to the structure at the same time. 
 * Again make whatever changes are required to the overall design. Provide adequate methods to access the state variables.
 * 5. Design and implement a mechanism for each event to output the description to a GUI interface (see Part 2).
 */

/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA generic container and relevant methods
 *             to simulate customer orders.
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */

package tme3;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 
 * <p> main method that run the whole system </p>
 *
 */
public class GreenhouseControls extends Controller {
    private static final long serialVersionUID = 1L;
    private static final DateFormat df = new SimpleDateFormat("[yyyy-MM-dd HH:mm:ss]");

    private final String pathDump = "dump.out";
    private final String pathLogErr = "error.log";

    public GreenhouseControls() {
        setVariable("errorcode", 0);  // 1 for WindowMalfunction and 2 for PowerOut
    }

    public int getError() {
        return (Integer) getVariable("errorcode");
    }

    public Fixable getFixable(int errorcode) {
        switch (errorcode) {
            case 1:
                return new FixWindow();
            case 2:
                return new PowerOn();
            default:
                return null;
        }
    }

    @Override
    protected void shutdown(String reason) {
        // TODO: Override the shutdown method
        // appendMessage(String.format("GreenhouseControls.shutdown(%s)\n", reason));
        for (Event event: eventList) {
            event.interrupt();
        }

        try {
            BufferedWriter bwErr = new BufferedWriter(new FileWriter(pathLogErr));
            bwErr.write(String.format("%s: %s\n", df.format(new Date()), reason));
            bwErr.close();

            FileOutputStream fos = new FileOutputStream(pathDump);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this);
            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.exit(0);
    }

    public static void printUsage() {
        System.out.println("Correct format: ");
        System.out.println("  java GreenhouseControls -f <filename>, or");
        System.out.println("  java GreenhouseControls -d dump.out");
    }

    // ---------------------------------------------------------
    public static void main(String[] args) {
        try {
            String option = args[0];
            String filename = args[1];

            if (!(option.equals("-f")) && !(option.equals("-d"))) {
                System.out.println("Invalid option");
                printUsage();
            }

            GreenhouseControls gc = new GreenhouseControls();

            if (option.equals("-f")) {
                gc.addEvent(new Restart(gc, 0, filename));
            } else if (option.equals("-d")) {
                // TODO: specify dump file path
                gc = Restore.restore(filename);
            }

            if (gc != null) {
                gc.run();
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Invalid number of parameters");
            printUsage();
        }
    }

} /// :~
