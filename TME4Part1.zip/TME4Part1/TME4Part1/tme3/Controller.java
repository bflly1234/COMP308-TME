/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */

package tme3;

import java.io.Serializable;
import java.util.*;

/**
 * <p>In the class controller,  apply JAVA concurrency technology 
 * so each event is individually categorized, 
 * timed, concurrent, and runs in TXT document </p>
 */

public class Controller implements Serializable {
    private static final long serialVersionUID = 1L;
    // A class from java.util to hold Event objects:
    protected final List<Event> eventList = Collections.synchronizedList(new ArrayList<>());
    protected List<TwoTuple<String, Object>> states;
    protected transient List<Thread> threads;

    public Controller() {
        this.states = Collections.synchronizedList(new ArrayList<>());
        this.threads = new ArrayList<>();
    }

    public void addEvent(Event c) {
        eventList.add(c);
    }

    public void restartEvents() {
        for (Event e : eventList) {
            e.start(this);
        }
    }

    public void run() {
        if (threads == null) {
            threads = new ArrayList<>();
        }
        while (threads.size() > 0 || eventList.size() > 0) {
            for (Event e : new ArrayList<Event>(eventList))
                if (e.isExpired()) {
                    eventList.remove(e);
                } else if (!e.isRunning()) {
                    Thread thread = new Thread(e);
                    threads.add(thread);
                    thread.start();
                }

            for (Thread thread : new ArrayList<>(threads)) {
                try {
                    thread.join();
                    threads.remove(thread);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    protected void shutdown(String reason) {
        appendMessage(String.format("Controller.shutdown(%s)\n", reason));
    }

    public synchronized void setVariable(String key, Object val) {
        for (TwoTuple<String, Object> state : new ArrayList<TwoTuple<String, Object>>(states)) {
            if (state.first.equals(key)) {
                states.remove(state);
                break;
            }
        }
        states.add(new TwoTuple<String, Object>(key, val));
    }

    public synchronized Object getVariable(String key) {
        for (TwoTuple<String, Object> state : states) {
            if (state.first.equals(key)) {
                return state.second;
            }
        }
        return null;
    }

    public synchronized void appendMessage(String message) {
        System.out.println(message);
    }
} /// :~
