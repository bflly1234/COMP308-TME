/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */

package tme3;

/**
 * 
 * exception class ControllerException that get/output message
 *
 */

public class ControllerException extends Exception {

    /**
     *  <p>Method that get/output message </p>
     */
    private static final long serialVersionUID = 1L;
    private String message;

    public ControllerException(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public String toString() {
        return getMessage();
    }
}
