/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */
package tme3;

/**
 * 
 * <p> class ThermostatNight that put the system on day setting </p>
 *
 */
public class ThermostatDay extends Event {
    private static final long serialVersionUID = 1L;

    public ThermostatDay(Controller ctl, long delayTime) {
        super(ctl, delayTime);
    }

    public void action() {
        // Put hardware control code here.
        ctl.setVariable("thermostat", "Day");
    }

    public String toString() {
        return "Thermostat on day setting";
    }
}
