/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */


package tme3;

import java.io.*;

/**
 * 
 * <p> method that determine event time/remain time/delay time
 * and retain relevent message when interrupt or expired </p>
 *
 */
public abstract class Event implements Serializable, Runnable {
    private static final long serialVersionUID = 1L;
    private long eventTime;
    private long remainTime;
    private volatile boolean running = false;
    protected final long delayTime;
    protected Controller ctl;

    public Event(Controller ctl, long delayTime) {
        this.delayTime = delayTime;
        this.remainTime = delayTime;
        this.ctl = ctl;
        start(ctl);
    }

    public void start(Controller ctl) { // Allows restarting
        if (remainTime == delayTime) {
            eventTime = System.currentTimeMillis() + delayTime;
        } else {
            eventTime = System.currentTimeMillis() + remainTime;
        }
        this.ctl = ctl;
    }

    public boolean ready() {
        if (System.currentTimeMillis() < eventTime) {
            remainTime = eventTime - System.currentTimeMillis();
        } else {
            remainTime = 0;
        }
        return System.currentTimeMillis() >= eventTime;
    }

    public void run() {
        // System.out.printf("run: %d\n", this.remainTime);
        if (remainTime < 0) {
            return;
        }
        running = true;
        try {
            while (running) {
                if (ready()) {
                    ctl.appendMessage(this.toString());
                    action();
                    remainTime = -1;
                    break;
                }
            }
            if (!running) {
                return;
            }
        } catch (ControllerException e) {
            remainTime = -1;
            ctl.shutdown(e.getMessage());
        }
        remainTime = -1;
        running = false;
    }

    public boolean isExpired() {
        return remainTime < 0;
    }

    public boolean isRunning() {
        return running;
    }

    public void interrupt() {
        running = false;
    }

    public abstract void action() throws ControllerException;
} /// :~
