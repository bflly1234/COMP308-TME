/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */
package tme3;

/**
 * 
 * <p> class that checks power on or off and show message </p>
 *
 */
public class PowerOut extends Event {
    private static final long serialVersionUID = 1L;

    public PowerOut(Controller ctl, long delayTime) {
        super(ctl, delayTime);
    }

    public void action() throws ControllerException {
        ctl.setVariable("poweron", false);
        ctl.setVariable("errorcode", 2);
        throw new ControllerException("Power is out");
    }

    public String toString() {
        return "Power is out";
    }
}
