/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */
package tme3;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * 
 * <p> interface fixable that logs fix.log </p>
 *
 */
public interface Fixable {
    String pathLogFix = "fix.log";
    DateFormat df = new SimpleDateFormat("[yyyy-MM-dd HH:mm:ss]");

    // turns Power on, fix window and zeros out error codes
    void fix(Controller ctl);

    // logs to a text file in the current directory called fix.log
    // prints to the console, and identify time and nature of
    // the fix
    void log(Controller ctl);
}
