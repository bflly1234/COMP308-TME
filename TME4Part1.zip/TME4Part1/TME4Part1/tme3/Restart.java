/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */
package tme3;

import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * <p> class that restart the system </p>
 *
 */
public class Restart extends Event {
    private static final long serialVersionUID = 1L;
    private final String eventsFile;

    public Restart(Controller ctl, long delayTime, String filename) {
        super(ctl, delayTime);
        eventsFile = filename;
    }

    public void action() {
        File fileEvents = new File(eventsFile);
        if (fileEvents.exists()) {
            Scanner scanner;
            try {
                scanner = new Scanner(fileEvents);
                Pattern p = Pattern.compile("(.*?)=(.*)");
                List<Map<String, String>> kvs = new ArrayList<>();

                while (scanner.hasNextLine()) {
                    Map<String, String> kv = new HashMap<>();
                    String line = scanner.nextLine();

                    for (String word : line.split(",")) {
                        Matcher matcher = p.matcher(word);
                        if (matcher.find()) {
                            // System.out.printf("{%s = %s}\n", matcher.group(1), matcher.group(2));
                            kv.put(matcher.group(1), matcher.group(2));
                        }
                    }

                    // System.out.println();
                    kvs.add(kv);
                }

                // System.out.println("EVENT: BEGIN");
                for (Map<String, String> kv : kvs) {
                    String event = kv.getOrDefault("Event", "");
                    try {
                        Constructor<?> x = Class.forName("tme3." + event).getConstructor(Controller.class, long.class);
                        for (int i = 0; i < Long.parseLong(kv.getOrDefault("rings", "1")); ++i) {
                            ctl.addEvent((Event) x.newInstance(ctl, Long.parseLong(kv.get("time")) * (i + 1)));
                        }
                        // System.out.println(event);
                    } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException | InstantiationException | InvocationTargetException e) {
                        e.printStackTrace();
                    }
                }
                // System.out.println("EVENT: END");

                scanner.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            ctl.addEvent(new ThermostatNight(ctl, 0));
            ctl.addEvent(new LightOn(ctl, 2000));
            ctl.addEvent(new WaterOff(ctl, 8000));
            ctl.addEvent(new ThermostatDay(ctl, 10000));
            ctl.addEvent(new Bell(ctl, 9000));
            ctl.addEvent(new WaterOn(ctl, 6000));
            ctl.addEvent(new LightOff(ctl, 4000));
            ctl.addEvent(new Terminate(ctl, 12000));
        }
    }

    public String toString() {
        return "Restarting system";
    }
}
