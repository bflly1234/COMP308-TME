/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */
package tme3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 * 
 * <p> class that restore the system after finding the error </p>
 *
 */
public class Restore {
    public static GreenhouseControls restore(String pathFileDump) {
        GreenhouseControls gc;
        ObjectInputStream ois;
        try {
            ois = new ObjectInputStream(new FileInputStream(pathFileDump));
            gc = (GreenhouseControls) ois.readObject();
            ois.close();

            Fixable fixable = gc.getFixable(gc.getError());
            if (fixable != null) {
                fixable.fix(gc);
                fixable.log(gc);
            }
            gc.restartEvents();

            return gc;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
}
