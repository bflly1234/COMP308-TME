/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency/GUI technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */
package tme3;

/**
 * 
 *  <p> class that checks fans on or off and show message </p>
 *
 */
public class FansOn extends Event {
    private static final long serialVersionUID = 1L;

    public FansOn(Controller ctl, long delayTime) {
        super(ctl, delayTime);
    }

    public void action() {
        ctl.setVariable("fans", true);
    }

    public String toString() {
        return "Fans are on";
    }
}
