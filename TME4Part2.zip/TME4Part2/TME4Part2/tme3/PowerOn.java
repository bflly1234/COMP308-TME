/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency/GUI technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */
package tme3;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

/**
 * 
 * <p> class that checks power on or off and show message </p>
 *
 */
public class PowerOn implements Fixable {
    @Override
    public void fix(Controller ctl) {
        ctl.setVariable("poweron", true);
        ctl.setVariable("errorcode", 0);
    }

    @Override
    public void log(Controller ctl) {
        try {
            File file = new File(pathLogFix);

            if (!file.exists()) {
                file.createNewFile();
            }
            BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
            String message = String.format("%s: %s", df.format(new Date()), "PowerOn");
            ctl.appendMessage(message);
            bw.write(message + '\n');

            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
