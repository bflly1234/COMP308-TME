/**
 * Part 2: GUI (45%)
 * This part aims to develop a Graphical User Interface used to control a GreenhouseControls object. You are free to design the layout of the interface. 
 * In case you are not sure you may develop the interface that looks like this, this or this. The minimum number of components and their functionalities of the GUI are:
 * 1. Each window of the GUI must have a scrollable text area, a set of 5 buttons, a pulldown menu and a popup menu.
 * 2. The pulldown menu consists of the following sub menus:
 * New window - creates a new GUI window. The new GUI window should associate with another GreenhouseControls object.
 * Close window - closes the current window. If the GreenhouseControls object is running, a warning message should be displayed to ask the user to confirm closing of the window. 
 * If the current window is the only window opened, exit the application.
 * Open Events - opens an events file. It should bring up a file dialog and let the user chooses an event file. If the chosen file is not a valid event file, display an appropriate error message.
 * Restore - opens a dump.out file and restore the GreenhouseControls object. It should bring up a file dialog and let the user choose a dump.out file. 
 * If the chosen file is not a valid dump.out file, display an appropriate error message. This option should be disabled if the GreenhouseControls is running.
 * Exit - exit the application. If any of the opened GUIs is running a GreenhouseControls object, display a warning message to ask the user to confirm the exit.
 * Associate a keyboard shortcut with each of the above menu items.
 * 3. The buttons:
 * Start - start to run a GreenhouseControls object. This button should be disabled if the GreenhouseControls object is running.
 * Restart - add a Restart object to rerun the current event file. This button should be disabled if no events file is read, or if the GreenhouseControls object is running.
 * Terminate - add a Terminate event to the running GreenhouseControls object. It should bring up a dialog to prompt for the delay time in milliseconds. 
 * This button should be disabled if the GreenhouseControls object is not running.
 * Suspend - suspends all running event threads. This button should be disabled if the GreenhouseControls object is not running.
 * Resume - resume all suspended event threads. This button should be disabled if the GreenhouseControls object is running.
 * 4. The popup menu should contain the following 5 submenus: Start, Restart, Terminate, Suspend, and Resume, with the same functionalities as the buttons.
 * 5. In addition to the above components, you are free to add as many components as necessary to make the GUI look nice.
 */

/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency/GUI technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */

package tme3;

import gui.Tme3Frame;

import java.awt.*;
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * 
 * <p> main method that run the whole system </p>
 *
 */
public class GreenhouseControls extends Controller {
    private static final long serialVersionUID = 1L;
    private static final DateFormat df = new SimpleDateFormat("[yyyy-MM-dd HH:mm:ss]");

    private final String pathDump = "dump.out";
    private final String pathLogErr = "error.log";
    private transient Tme3Frame frame;

    public GreenhouseControls() {
        setVariable("errorcode", 0);  // 1 for WindowMalfunction and 2 for PowerOut
    }

    public int getError() {
        return (Integer) getVariable("errorcode");
    }

    public Fixable getFixable(int errorcode) {
        switch (errorcode) {
            case 1:
                return new FixWindow();
            case 2:
                return new PowerOn();
            default:
                return null;
        }
    }

    public void recoverFromDump() {
        threads = Collections.synchronizedList(new ArrayList<>());
        for (Event e : eventList) {
            e.start(this);

            if (!e.isExpired()) {
                Thread thread = new Thread(e);
                threads.add(thread);
                thread.start();
            }
        }
    }

    @Override
    protected void shutdown(String reason) {
        // appendMessage(String.format("GreenhouseControls.shutdown(%s)\n", reason));
        try {
            BufferedWriter bwErr = new BufferedWriter(new FileWriter(pathLogErr));
            bwErr.write(String.format("%s: %s\n", df.format(new Date()), reason));
            bwErr.close();

            FileOutputStream fos = new FileOutputStream(pathDump);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this);
            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        terminate();
    }

    public boolean isRunning() {
        for (Thread thread : new ArrayList<>(threads)) {
            if (thread.isAlive()) {
                return true;
            }
        }
        return false;
    }

    public void suspendAll() {
        for (Thread thread : new ArrayList<>(threads)) {
            thread.suspend();
        }
    }

    public void resumeAll() {
        for (Thread thread : new ArrayList<>(threads)) {
            thread.resume();
        }
    }

    public synchronized void appendMessage(String message) {
        if (this.frame != null) {
            frame.appendMessage(message);
        } else {
            super.appendMessage(message);
        }
    }

    public void bindFrame(Tme3Frame frame) {
        this.frame = frame;
    }

    public static void printUsage() {
        System.out.println("Correct format: ");
        System.out.println("  java GreenhouseControls -f <filename>, or");
        System.out.println("  java GreenhouseControls -d dump.out");
    }

    // ---------------------------------------------------------
    public static void main(String[] args) {
        try {
            String option = args[0];
            String filename = args[1];

            if (!(option.equals("-f")) && !(option.equals("-d"))) {
                System.out.println("Invalid option");
                printUsage();
            }

            GreenhouseControls gc = new GreenhouseControls();

            if (option.equals("-f")) {
                gc.addEvent(new Restart(gc, 0, filename));
            } else if (option.equals("-d")) {
                try {
                    gc = Restore.restore(filename);
                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                    gc = null;
                }
            }

            if (gc != null) {
                gc.run();
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

            Tme3Frame frame = new Tme3Frame();
            frame.setSize(800, 600);
            frame.setLocation((screenSize.width - frame.getWidth()) / 2, (screenSize.height - frame.getHeight()) / 2);
            frame.setVisible(true);
        }
    }

} /// :~
