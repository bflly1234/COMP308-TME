/** 
 *             TME3, COMP308
 * Class:      GreenHouseCOntrols.java
 * Purpose:    The below program will mainly use JAVA concurrency/GUI technology 
 *             to simulate a greenhouse control system
 * @author:    Baofeng Zhang
 * Student ID: 3354730
 * Date:       Jan 22, 2020
 * Version     1.0
 * 
 * Based on:   Java (Beginner) Programming Tutorials
 *             Web access:
 *             https://www.youtube.com/channel/UCJbPGzawDH1njbqV-D5HqKw
 */

package tme3;

import java.io.*;

/**
 * 
 * <p> method that determine event time/remain time/delay time
 * and retain relevent message when interrupt or expired </p>
 *
 */
public abstract class Event implements Serializable, Runnable {
    private static final long serialVersionUID = 1L;
    protected final long delayTime;
    protected long remainTime;
    protected Controller ctl;

    public Event(Controller ctl, long delayTime) {
        this.delayTime = delayTime;
        this.remainTime = delayTime;
        this.ctl = ctl;
        start(ctl);
    }

    public void start(Controller ctl) { // Allows restarting
        this.ctl = ctl;
    }

    public boolean ready() {
        return remainTime == 0;
    }

    public void run() {
        // System.out.printf("run: %d\n", this.remainTime);
        if (remainTime < 0) {
            return;
        }
        try {
            while (true) {
                Thread.sleep(1);
                remainTime = remainTime > 1 ? remainTime - 1 : 0;
                if (ready()) {
                    ctl.appendMessage(this.toString());
                    action();
                    remainTime = -1;
                    break;
                }
            }
        } catch (ControllerException e) {
            remainTime = -1;
            ctl.shutdown(e.getMessage());
        } catch (InterruptedException ignored) {
        }
    }

    public boolean isExpired() {
        return remainTime < 0;
    }

    public abstract void action() throws ControllerException;
} /// :~
