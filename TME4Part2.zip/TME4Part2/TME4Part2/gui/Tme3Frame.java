package gui;

import tme3.GreenhouseControls;
import tme3.Restart;
import tme3.Restore;
import tme3.Terminate;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import javax.swing.*;

public class Tme3Frame extends JFrame {
    private GreenhouseControls gc;
    private String pathEvents;

    public Tme3Frame() {
        initComponents();
    }

    public boolean isGcRunning() {
        return gc != null && gc.isRunning();
    }

    public synchronized void appendMessage(String message) {
        textAreaMessage.append(message + '\n');
    }

    private void closeThisWindow() {
        if (gc != null && gc.isRunning()) {
            int result = JOptionPane.showOptionDialog(
                    this,
                    "GreenhouseControls is still running, are you sure to close it?",
                    "Warning",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.WARNING_MESSAGE,
                    null,
                    null,
                    null);
            if (result == JOptionPane.OK_OPTION) {
                gc.terminate();
                dispose();
            }
        } else {
            dispose();
        }
    }

    private void onStart() {
        if (gc != null && gc.isRunning()) {
            appendMessage("Error: GreenhouseControls is running!");
        } else {
            gc = new GreenhouseControls();
            gc.bindFrame(this);
        }
    }

    private void onRestart() {
        if (gc != null && pathEvents != null && (new File(pathEvents)).isFile()) {
            gc.addEvent(new Restart(gc, 0, pathEvents));
        } else {
            appendMessage("Error: GreenhouseControls is not running or the events file is not loaded!");
        }
    }

    private void onTerminate() {
        if (gc != null && gc.isRunning()) {
            String strDelayTime = JOptionPane.showInputDialog(this, "Delay Time (ms): ");
            try {
                gc.addEvent(new Terminate(gc, Long.parseLong(strDelayTime)));
            } catch (NumberFormatException exception) {
                appendMessage("Error: The input data format is incorrect!");
            }
        } else {
            appendMessage("Error: GreenhouseControls is not running!");
        }
    }

    private void onSuspend() {
        if (gc != null && gc.isRunning()) {
            gc.suspendAll();
            appendMessage("Info: All threads have been suspended!");
        } else {
            appendMessage("Error: GreenhouseControls is not running!");
        }
    }

    private void onResume() {
        if (gc != null && gc.isRunning()) {
            gc.resumeAll();
            appendMessage("Info: All threads have been resumed!");
        } else {
            appendMessage("Error: GreenhouseControls is not running!");
        }
    }

    private void thisWindowClosing(WindowEvent e) {
        closeThisWindow();
    }

    private void thisMouseClicked(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON3) {
            popupMenuMain.show(e.getComponent(), e.getX(), e.getY());
        }
    }

    private void textAreaMessageMouseClicked(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON3) {
            popupMenuMain.show(e.getComponent(), e.getX(), e.getY());
        }
    }

    private void menuItemNewWindowActionPerformed(ActionEvent e) {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        Tme3Frame frame = new Tme3Frame();
        frame.setSize(800, 600);
        frame.setLocation((screenSize.width - frame.getWidth()) / 2, (screenSize.height - frame.getHeight()) / 2);
        frame.setVisible(true);
    }

    private void menuItemCloseWindowActionPerformed(ActionEvent e) {
        closeThisWindow();
    }

    private void menuItemOpenEventsActionPerformed(ActionEvent e) {
        FileDialog fileDialog = new FileDialog(this, "Open Events File", FileDialog.LOAD);
        fileDialog.setVisible(true);
        String pathParent = fileDialog.getDirectory();
        String pathFile = fileDialog.getFile();
        if (pathParent != null && pathFile != null) {
            String pathEvents = fileDialog.getDirectory() + fileDialog.getFile();
            File fileEvents = new File(pathEvents);
            if (pathEvents.endsWith(".txt") && fileEvents.exists() && fileEvents.isFile()) {
                this.pathEvents = pathEvents;
                labelEventsPath.setText(String.format("Events File Path: %s", pathEvents));
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "The selected file is not a valid event file!",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void menuItemRestoreActionPerformed(ActionEvent e) {
        if (gc != null && gc.isRunning()) {
            JOptionPane.showMessageDialog(
                    this,
                    "GreenhouseControls is currently running!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        } else {
            FileDialog fileDialog = new FileDialog(this, "Open Events File", FileDialog.LOAD);
            fileDialog.setVisible(true);
            String pathParent = fileDialog.getDirectory();
            String pathFile = fileDialog.getFile();
            if (pathParent != null && pathFile != null) {
                String pathDump = fileDialog.getDirectory() + fileDialog.getFile();
                try {
                    gc = Restore.restore(pathDump, this);
                } catch (IOException | ClassNotFoundException exception) {
                    // exception.printStackTrace();
                    JOptionPane.showMessageDialog(
                            this,
                            "The selected file is not a valid restore file!",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private void menuItemExitActionPerformed(ActionEvent e) {
        boolean stillRunning = false;
        for (Frame frame : JFrame.getFrames()) {
            if (((Tme3Frame)frame).isGcRunning()) {
                stillRunning = true;
                break;
            }
        }
        if (stillRunning) {
            int result = JOptionPane.showOptionDialog(
                    this,
                    "There is still at least 1 running Greenhouse Controls, are you sure you want to quit?",
                    "Warning",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.WARNING_MESSAGE,
                    null,
                    null,
                    null);
            if (result == JOptionPane.OK_OPTION) {
                System.exit(0);
            }
        } else {
            System.exit(0);
        }
    }

    private void buttonStartActionPerformed(ActionEvent e) {
        onStart();
    }

    private void buttonRestartActionPerformed(ActionEvent e) {
        onRestart();
    }

    private void buttonTerminateActionPerformed(ActionEvent e) {
        onTerminate();
    }

    private void buttonSuspendActionPerformed(ActionEvent e) {
        onSuspend();
    }

    private void buttonResumeActionPerformed(ActionEvent e) {
        onResume();
    }

    private void menuItemStartActionPerformed(ActionEvent e) {
        onStart();
    }

    private void menuItemRestartActionPerformed(ActionEvent e) {
        onRestart();
    }

    private void menuItemTerminateActionPerformed(ActionEvent e) {
        onTerminate();
    }

    private void menuItemSuspendActionPerformed(ActionEvent e) {
        onSuspend();
    }

    private void menuItemResumeActionPerformed(ActionEvent e) {
        onResume();
    }

    private void initComponents() {
        menuBarMain = new JMenuBar();
        menuFile = new JMenu();
        menuItemNewWindow = new JMenuItem();
        menuItemCloseWindow = new JMenuItem();
        menuItemOpenEvents = new JMenuItem();
        menuItemRestore = new JMenuItem();
        menuItemExit = new JMenuItem();
        textAreaMessage = new JTextArea();
        panelBottom = new JPanel();
        buttonStart = new JButton();
        buttonRestart = new JButton();
        buttonTerminate = new JButton();
        buttonSuspend = new JButton();
        buttonResume = new JButton();
        labelEventsPath = new JLabel();
        popupMenuMain = new JPopupMenu();
        menuItemStart = new JMenuItem();
        menuItemRestart = new JMenuItem();
        menuItemTerminate = new JMenuItem();
        menuItemSuspend = new JMenuItem();
        menuItemResume = new JMenuItem();

        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                thisMouseClicked(e);
            }
        });
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                thisWindowClosing(e);
            }
        });
        var contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        //======== menuBarMain ========
        {

            //======== menuFile ========
            {
                menuFile.setText("File");
                menuFile.setMnemonic('F');

                //---- menuItemNewWindow ----
                menuItemNewWindow.setText("New Window");
                menuItemNewWindow.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, KeyEvent.CTRL_MASK));
                menuItemNewWindow.addActionListener(e -> menuItemNewWindowActionPerformed(e));
                menuFile.add(menuItemNewWindow);

                //---- menuItemCloseWindow ----
                menuItemCloseWindow.setText("Close Window");
                menuItemCloseWindow.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W, KeyEvent.CTRL_MASK));
                menuItemCloseWindow.addActionListener(e -> menuItemCloseWindowActionPerformed(e));
                menuFile.add(menuItemCloseWindow);

                //---- menuItemOpenEvents ----
                menuItemOpenEvents.setText("Open Events");
                menuItemOpenEvents.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, KeyEvent.CTRL_MASK));
                menuItemOpenEvents.addActionListener(e -> menuItemOpenEventsActionPerformed(e));
                menuFile.add(menuItemOpenEvents);

                //---- menuItemRestore ----
                menuItemRestore.setText("Restore");
                menuItemRestore.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, KeyEvent.CTRL_MASK));
                menuItemRestore.addActionListener(e -> menuItemRestoreActionPerformed(e));
                menuFile.add(menuItemRestore);

                //---- menuItemExit ----
                menuItemExit.setText("Exit");
                menuItemExit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, KeyEvent.ALT_MASK));
                menuItemExit.addActionListener(e -> menuItemExitActionPerformed(e));
                menuFile.add(menuItemExit);
            }
            menuBarMain.add(menuFile);
        }
        setJMenuBar(menuBarMain);

        //---- textAreaMessage ----
        textAreaMessage.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                textAreaMessageMouseClicked(e);
            }
        });
        contentPane.add(new JScrollPane(textAreaMessage), BorderLayout.CENTER);

        //======== panelBottom ========
        {
            panelBottom.setLayout(new BoxLayout(panelBottom, BoxLayout.X_AXIS));

            //---- buttonStart ----
            buttonStart.setText("Start");
            buttonStart.addActionListener(e -> buttonStartActionPerformed(e));
            panelBottom.add(buttonStart);

            //---- buttonRestart ----
            buttonRestart.setText("Restart");
            buttonRestart.addActionListener(e -> buttonRestartActionPerformed(e));
            panelBottom.add(buttonRestart);

            //---- buttonTerminate ----
            buttonTerminate.setText("Terminate");
            buttonTerminate.addActionListener(e -> buttonTerminateActionPerformed(e));
            panelBottom.add(buttonTerminate);

            //---- buttonSuspend ----
            buttonSuspend.setText("Suspend");
            buttonSuspend.addActionListener(e -> buttonSuspendActionPerformed(e));
            panelBottom.add(buttonSuspend);

            //---- buttonResume ----
            buttonResume.setText("Resume");
            buttonResume.addActionListener(e -> buttonResumeActionPerformed(e));
            panelBottom.add(buttonResume);
        }
        contentPane.add(panelBottom, BorderLayout.SOUTH);

        //---- labelEventsPath ----
        labelEventsPath.setText("Events File Path: ");
        contentPane.add(labelEventsPath, BorderLayout.NORTH);
        pack();
        setLocationRelativeTo(getOwner());

        //======== popupMenuMain ========
        {

            //---- menuItemStart ----
            menuItemStart.setText("Start");
            menuItemStart.addActionListener(e -> menuItemStartActionPerformed(e));
            popupMenuMain.add(menuItemStart);

            //---- menuItemRestart ----
            menuItemRestart.setText("Restart");
            menuItemRestart.addActionListener(e -> menuItemRestartActionPerformed(e));
            popupMenuMain.add(menuItemRestart);

            //---- menuItemTerminate ----
            menuItemTerminate.setText("Terminate");
            menuItemTerminate.addActionListener(e -> menuItemTerminateActionPerformed(e));
            popupMenuMain.add(menuItemTerminate);

            //---- menuItemSuspend ----
            menuItemSuspend.setText("Suspend");
            menuItemSuspend.addActionListener(e -> menuItemSuspendActionPerformed(e));
            popupMenuMain.add(menuItemSuspend);

            //---- menuItemResume ----
            menuItemResume.setText("Resume");
            menuItemResume.addActionListener(e -> menuItemResumeActionPerformed(e));
            popupMenuMain.add(menuItemResume);
        }
    }

    private JMenuBar menuBarMain;
    private JMenu menuFile;
    private JMenuItem menuItemNewWindow;
    private JMenuItem menuItemCloseWindow;
    private JMenuItem menuItemOpenEvents;
    private JMenuItem menuItemRestore;
    private JMenuItem menuItemExit;
    private JTextArea textAreaMessage;
    private JPanel panelBottom;
    private JButton buttonStart;
    private JButton buttonRestart;
    private JButton buttonTerminate;
    private JButton buttonSuspend;
    private JButton buttonResume;
    private JLabel labelEventsPath;
    private JPopupMenu popupMenuMain;
    private JMenuItem menuItemStart;
    private JMenuItem menuItemRestart;
    private JMenuItem menuItemTerminate;
    private JMenuItem menuItemSuspend;
    private JMenuItem menuItemResume;
}
