<?php
  require_once('bm_functions.php');
  session_start();
  do_html_header('Change password');

  $old_passwd = $_POST['old_passwd'];
  $new_passwd = $_POST['new_passwd'];
  $new_passwd2 = $_POST['new_passwd2'];

  try {
       check_valid_user();
      if (!filled_out($_POST)) {
      throw new Exception('You did not complete, please continue to fill in!');
      }
      if(!preg_match("/^[A-Za-z0-9_]{6,16}+$/u",$old_passwd)){
          throw new Exception('Old password contains invalid characters or length error, please re-enter!');
      }
      if ($new_passwd !== $new_passwd2) {
          throw new Exception('The password entered twice is inconsistent, please input again!');
      }
      if(!preg_match("/^[A-Za-z0-9_]{6,16}+$/u",$new_passwd)){
          throw new Exception('Password contains invalid characters or length error, please re-enter!');
      }
      if(!preg_match("/^[A-Za-z0-9_]{6,16}+$/u",$new_passwd2)){
          throw new Exception('Password contains invalid characters or length error, please re-enter!');
      }
      // attempt update
      change_password($_SESSION['valid_user'], $old_passwd, $new_passwd);
      echo 'Password change successful!<br />';
      do_html_url('member.php', 'Home Page');
  }
  catch (Exception $e) {
    echo $e->getMessage();
  }
  do_html_footer();
?>
