(function () {
    var bannerCarousel = document.getElementById('bannerCarousel');
    var circleOl = document.getElementById('circleOl');
    var circleList = circleOl.getElementsByTagName('li');
    var banner = document.getElementById('banner');

    var fouthPic = bannerCarousel.firstElementChild.cloneNode(true);
    bannerCarousel.appendChild(fouthPic);
    var nextPage = 0;

    // Event handler for the right button
    function bannerNextPage() {
        // With the transition
        bannerCarousel.style.transition = 'transform .5s ease 0s';
        // Next page going to add 1
        nextPage++;
        // pull
        bannerCarousel.style.transform = 'translateX(' + -25 * nextPage + '%)';
        // Check if it's the last one, and if it is, teleport it back
        if (nextPage > 2) {
            setTimeout(function () {
                // Remove the transition
                bannerCarousel.style.transition = 'none';
                // Delete transform attribute
                bannerCarousel.style.transform = 'none';
                // The global image number changes to 0
                nextPage = 0;
            }, 500);
        }
        // Set the dot
        setCircles();
    };

    // If the dot number is idx, the name of the current class will be specified. Otherwise, the name of the Li class will not be specified
    function setCircles() {
        // Go through, go through zero, one, two, three, four.Every time we traverse a number, we will compare it to idx. If it is equal, we will change the name of the setting class to current, otherwise we will remove the name of the setting class.
        for (var i = 0; i <= 2; i++) {
            // The remainder of 0, 1, 2, 3, 4 divided by 5 is itself, but 5 divided by 5 is 0.
            // The purpose of the %5 here is for the right button and it's going to be idx for a fraction of a second for 5,500 milliseconds before it goes to zero.
            if (i == nextPage % 3) {
                circleList[i].className = 'current';
            } else {
                circleList[i].className = '';
            }
        }
    }

    // Event delegate, dot listening
    circleOl.onclick = function (e) {
        if (e.target.tagName.toLowerCase() == 'li') {
            // You get the data-n property on Li, which is just n
            var n = Number(e.target.getAttribute('data-n'));
            // Change nextpage
            nextPage = n;
            // pull
            bannerCarousel.style.transform = 'translateX(' + -25 * nextPage + '%)';
            // Call the change dot function
            setCircles();
        }
    }

    // Timer, automatic rotation
    var timer = setInterval(bannerNextPage, 2000);

    // Mouse entry, automatic rotation pause
    banner.onmouseenter = function () {
        clearInterval(timer);
    }

    // Mouse away, automatic rotation begins
    banner.onmouseleave = function () {
        clearInterval(timer);
        // Set timer
        timer = setInterval(bannerNextPage, 2000);
    }
})()