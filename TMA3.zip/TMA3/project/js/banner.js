$(function () {
    const $box = $(".box"),
        $ul = $box.children("ul"),
        $li = $ul.children(),
        $ol = $ul.next("ol"),
        $btn = $ol.next("#btn"),
        $btnLeft = $btn.children(".btnLeft"),
        $btnRight = $btn.children(".btnRight")

    // Gets the number of images and the width of each image
    let num = $li.length
    let width = $li.eq(0).outerWidth()

    // Append the 0th image to the end
    $ul.append($li.eq(0).clone())

    // Add width to ul
    $ul.width((num + 1) * width)

    // Automatically round
    auto()

    /*------------------------dots-----------------------------*/
    //Create dots
    for (let i = 0; i < num; i++) {
        $("<li>").addClass(i === 0 ? "active" : "").appendTo($ol)
    }

    // Defines the index of the current and previous image
    let index = 0
    let lastIndex = 0

    // The motion state of ul is static by default
    let isMove = false

    // Click the dot to switch images
    // Ol li
    let olis = $ol.children()
    olis.on("click", function () {
        if (isMove) {
            return
        }
        isMove = true
        // This refers to the dot currently clicked. It is native and is to be converted to jQuery
        // Let's record an index
        lastIndex = index
        index = $(this).index()
        // Remove all LI ACTIVE
        olis.eq(lastIndex).removeClass("active")
        olis.eq(index).addClass("active")


        //The picture switches with the dot
        $ul.animate({
            left: -index * width
        }, 1000, function () {
            isMove = false
        })

    })

    /*-----------------------Right arrow-----------------------*/
    $btnRight.on("click", function () {
        if (isMove) {
            return
        }
        isMove = true
        // Determine whether to go to the last picture
        lastIndex = index
        index++
        if (index > num - 1) {
            $ul.animate({
                left: -index * width
            }, 1000, function () {
                index = 0
                $ul.css("left", 0)
                isMove = false
            })
        } else {
            $ul.animate({
                left: -index * width
            }, 1000, function () {
                isMove = false
            })
        }
        olis.eq(lastIndex).removeClass("active")
        olis.eq(index).addClass("active")
    })

    /*----------------------------The left arrow---------------------*/
    $btnLeft.on("click", function () {
        // Determine whether to go to the first image
        if (isMove) {
            return
        }
        isMove = true
        lastIndex = index
        index--
        // So index is a negative number
        if (index < 0) {
            index = num - 1
            $ul.css("left", -num * width).animate({
                left: -index * width
            }, 1000, function () {
                isMove = false
            })
        } else {
            $ul.animate({
                left: -index * width
            }, 1000, function () {
                isMove = false
            })
        }
        olis.eq(lastIndex).removeClass("active")
        olis.eq(index).addClass("active")
    })

    /*--------------------------Automatic rotation ------------------------*/
    function auto() {
        $box.timer = setInterval(() => {
            $btnRight.trigger("click")
        }, 2000)
    }

    /*--------------------------Move in move out event ---------------------*/
    $box.hover(function () {
        clearInterval($box.timer)
        console.log(index)
    }, function () {
        auto()
    })
})