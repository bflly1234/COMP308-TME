(function() {
    var backtotop = document.getElementById('backtotop');

    var timer;

    // Returns the listener for the top button
    backtotop.onclick = function() {
        clearInterval(timer);
        // Set timer
        timer = setInterval(function() {
            document.documentElement.scrollTop -= 100;

            if (document.documentElement.scrollTop <= 0) {
                clearInterval(timer);
            }
        }, 20);
    };

    //Listen for page scrolling
    window.onscroll = function () {
        // Scroll values
        var scrollTop = document.documentElement.scrollTop || window.scrollY;

        // The page is not scrolled, so the Back to Top button is hidden
        if (scrollTop == 0) {
            backtotop.style.display = 'none';
        } else {
            backtotop.style.display = 'block';
        }
    }
})();