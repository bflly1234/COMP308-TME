(function ($) {
    var $list = $('#productCarousel');
    var lock = true;
    var nextPage = 0;
    $('#nextbtn').click(function () {
        if (!lock) return;
        lock = false;
        nextPage++;
        if (nextPage < 5) {
            $list.css('left', -nextPage * 222);//368
        } else {
            $list.css('left', -1110);//2208
            nextPage = 5;
        }
        setTimeout(function () {
            lock = true;
        }, 500);
    })
    $('#prevbtn').click(function () {
        if (!lock) return;
        lock = false;
        nextPage--;
        if (nextPage > 0) {
            $list.css('left', -nextPage * 222);//368
        } else {
            $list.css('left', 0);//2208
            nextPage = 0;
        }
        setTimeout(function () {
            lock = true;
        }, 500);
    })
})(jQuery)