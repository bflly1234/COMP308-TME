<?php
 require_once('bm_functions.php');
 do_html_header('User registration');

?>
<form method="post" action="register_new.php">
    <table bgcolor="#cccccc" align="center" width="600">
        <tr>
            <td colspan="2" align="right"><h2>User registration</h2></td></tr>
        <tr>
            <td><b> UserName： </b></td>
            <td><input type="text" name="username" size="30" maxlength="30"/></td>
            <td>(The value contains a maximum of 16 characters, including digits, letters, and underscores)</td></tr>
        <tr>
            <td><b> password： </b></td>
            <td ><input type="password" name="passwd" size="30" maxlength="30"/></td>
            <td>(The value contains a maximum of 16 characters, including digits, letters, and underscores)</td></tr>
        <tr>
            <td><b> Confirm password： </b</td>
            <td><input type="password" name="passwd2" size="30" maxlength="30"/></td>
            <td>(The value contains a maximum of 16 characters, including digits, letters, and underscores)</td></tr>
        <tr>
            <td><b> Email Address： </b</td>
            <td><input type="text" name="email" size="30" maxlength="100"/></td>
            <td></td></tr>
        <tr>
            <td colspan=2 align="right">
                <input type="submit" value="Submit"></td></tr>

    </table>
</form>
<?php
do_html_footer();
?>
