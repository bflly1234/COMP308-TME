<?php

//Import function library
require_once('bm_functions.php');
session_start();

$username = $_POST['username'];
$passwd = $_POST['passwd'];

if ($username && $passwd) {
  try  {

      if(!preg_match("/^[\x{4e00}-\x{9fa5}A-Za-z0-9_]{6,16}+$/u",$username)){
          throw new Exception('User name contains invalid characters or length error, please re-enter.');
      }
      if(!preg_match("/^[A-Za-z0-9_]{6,16}+$/u",$passwd)){
          throw new Exception('Password contains invalid characters or length error, please re-enter.');
      }
      //Verifying User Information
      login($username, $passwd);
      //Saves user information to the session
      $_SESSION['valid_user'] = $username;
  }
  catch(Exception $e)  {
    do_html_header('Problem:');
    echo $e->getMessage();
    do_html_url('login.php', 'Re-longin');
    do_html_footer();
    exit;
  }
}

//After a successful longin
do_html_header('Home');
//Verify session registration information
check_valid_user();
display_body();
display_footer();
?>
