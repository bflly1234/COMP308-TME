<?php

// Import function library
require_once('bm_functions.php');
session_start();
$old_user = $_SESSION['valid_user'];

//The cancellation of the session
unset($_SESSION['valid_user']);
$result_dest = session_destroy();


do_html_header('Logging Out');

if (!empty($old_user)) {
  if ($result_dest)  {
    echo 'You have logged out！<br />';
    do_html_url('index.html', 'Home Page');
  } else {

    echo 'Error logging out!<br />';
  }
} else {
  echo 'You are not logged in, can not log out!<br />';
}

do_html_footer();

?>
