
<?php
 require_once('bm_functions.php');
 do_html_header('');
?>

<body>
<br>
<br>

<form method="post" action="member.php" >
    <table bgcolor="#cccccc" align="center" height="200" width="600" >
        <tr>
            <td colspan="2" align="right"><h2>Login</h2></td>
        <tr>
            <td><b>User Name:</b></td>
            <td><input type="text" name="username" size="30" maxlength="16"/></td>
            <td>(The value contains 6 to 16 characters, including digits, letters, and underscores)</td></tr>
        <tr>
            <td><b>Password:</b></td>
            <td><input type="password" name="passwd" size="30" maxlength="16"/></td>
            <td>(The value contains 6 to 16 characters, including digits, letters, and underscores)</td></tr>
        <tr>
            <td colspan="2" align="center">
                <input type="submit" value="submit"/></td></tr>
        <tr>
            <td colspan="2"><a href="register_form.php">No account yet?</a></td>
        </tr>
    </table>
</form>
</body>
