<?php

//Import function library
require_once('bm_functions.php');
session_start();

//After a successful longin
//Verify session registration information
check_valid_user();
?>

<!DOCTYPE html>
<html lang="en" class="no-js">

<head lang="en">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link rel="stylesheet" href="./css/bootstrap.min.css">
	<link rel="stylesheet" href="http://libs.useso.com/js/font-awesome/4.2.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="./css/style.css">
	<link rel="stylesheet" href="./css/css.css">
	<link rel="stylesheet" href="./css/reset.css">
	<link rel="stylesheet" href="./css/base.css">
</head>

<body>
	<section class="navigation">
		<div class="center-wrap">
			<h1 class="logo">
				Fresh Food
			</h1>
			<ul>
				<li>
					<a href="member.php">
						<img src="Images/home-gry.png" alt="">
						<img src="Images/home-white.png" alt="">
						<span>Home Page</span>
					</a>
				</li>
				<li>
					<a href="">
						<img src="Images/abouts-gry.png" alt="">
						<img src="Images/abouts-white.png" alt="">
						<span>About us</span>
					</a>
				</li>
				<li>
					<a href="return.php">
						<img src="Images/kefu-gry.png" alt="">
						<img src="Images/kefu-white.png" alt="">
						<span>Return</span>
					</a>
				</li>
				<li>
					<a href="hot.php">
						<img src="Images/chanpin-gry.png" alt="">
						<img src="Images/chanpin-white.png" alt="">
						<span>Hot Product</span>
					</a>
				</li>
				<li>
					<a href="">
						<img src="Images/fuwu-gry.png" alt="">
						<img src="Images/fuwu-white.png" alt="">
						<span>On Sale</span>
					</a>
				</li>
			</ul>
			<div class="search-bar">
				<input type="text" placeholder="search for">
				<button><img src="images/search.png" alt=""></button>
			</div>
		</div>
	</section>
	<div class="ct-pageWrapper">
		<main>
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<div class="widget">
							<h2 class="widget-header">Shopping Cart</h2>
							<div class="ct-cart"></div>
						</div>
					</div>
					<div class="col-md-9">
						<div class="row">
							<div class="col-sm-4">
								<div class="ct-product">
									<div class="image"><img src="Images/product-01.jpg" alt=""></div>
									<div class="inner"><a href="#" class="btn btn-motive ct-product-button"><i class="fa fa-shopping-cart"></i></a>
										<h2 class="ct-product-title">Greek yogurt</h2>
										<p class="ct-product-description">A very delicious Greek yogurt...</p><span class="ct-product-price">$3.99</span>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="ct-product">
									<div class="image"><img src="Images/product-02.jpg" alt=""></div>
									<div class="inner"><a href="#" class="btn btn-motive ct-product-button"><i class="fa fa-shopping-cart"></i></a>
										<h2 class="ct-product-title">Organic strawberries</h2>
										<p class="ct-product-description">A very delicious Organic strawberries ...</p><span class="ct-product-price">$34.99</span>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="ct-product">
									<div class="image"><img src="Images/product-03.jpg" alt=""></div>
									<div class="inner"><a href="#" class="btn btn-motive ct-product-button"><i class="fa fa-shopping-cart"></i></a>
										<h2 class="ct-product-title">Organic avocados</h2>
										<p class="ct-product-description">A very delicious Organic avocados ...</p><span class="ct-product-price">$59.99</span>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="ct-product">
									<div class="image"><img src="Images/product-04.jpg" alt=""></div>
									<div class="inner"><a href="#" class="btn btn-motive ct-product-button"><i class="fa fa-shopping-cart"></i></a>
										<h2 class="ct-product-title">Fresh salmon</h2>
										<p class="ct-product-description">A very delicious Fresh salmon ...</p><span class="ct-product-price">$9.99</span>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="ct-product">
									<div class="image"><img src="Images/product-05.jpg" alt=""></div>
									<div class="inner"><a href="#" class="btn btn-motive ct-product-button"><i class="fa fa-shopping-cart"></i></a>
										<h2 class="ct-product-title">Fruit cheese</h2>
										<p class="ct-product-description">A very delicious Fruit cheese...</p><span class="ct-product-price">$3.99</span>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="ct-product">
									<div class="image"><img src="Images/product-06.jpg" alt=""></div>
									<div class="inner"><a href="#" class="btn btn-motive ct-product-button"><i class="fa fa-shopping-cart"></i></a>
										<h2 class="ct-product-title">umplings</h2>
										<p class="ct-product-description">A very delicious dumplings ...</p><span class="ct-product-price">$13.99</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>

		<script src="./js/jquery-3.4.1.min.js"></script>
		<script src="./js/shop.min.js"></script>
		<script>
			$('body').ctshop({
				currency: '$',
				paypal: {
					currency_code: 'CAN'
				}
			});
		</script>
	</div>
</body>

</html>