<?php

  require_once('output_functins.php');

// Connect to database function
function db_connect() {
    $result = new mysqli('localhost', 'baofenzh', 'baofenzhabyz', 'baofenzh');
    if (!$result) {
        throw new Exception('Unable to connect to database.');
    } else {
        return $result;
    }
}

//Output all bookmark functions as a form
function get_user_urls($username) {


    $conn = db_connect();
    $result = $conn->query("select bm_URL from bookmark  where username = '".$username."'");
    if (!$result) {
        return false;
    }
    $url_array = array();
    for ($count = 1; $row = $result->fetch_row(); ++$count) {
        $url_array[$count] = $row[0];
    }
    return $url_array;
}

//Check if the form is filled in as a function
function filled_out($form_vars) {

    foreach ($form_vars as $key => $value) {
        if ((!isset($key)) || ($value == '')) {
            return false;
        }
    }
    return true;
}


// Function to check whether the mail address is valid
function valid_email($address) {
    if (preg_match('^[a-zA-Z0-9_\.\-]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$^', $address)) {
        return true;
    } else {
        return false;
    }
}


//Delete the bookmark function from the database
function delete_bm($user, $url) {

    $conn = db_connect();
    if (!$conn->query("delete from bookmark where username='".$user."' and bm_url='".$url."'")) {
        throw new Exception('Bookmarks cannot be deleted.');
    }
    return true;
}


//Register user information functions with the database
function register($username, $email, $password) {
    $conn = db_connect();
    $result = $conn->query("select * from user where username='".$username."'");
    if (!$result) {
        throw new Exception('Unable to execute query, please try again.');
    }

    if ($result->num_rows>0) {
        throw new Exception('The user name already exists, please fill in again.');
    }
    $result = $conn->query("insert into user values('".$username."', sha1('".$password."'), '".$email."')");
    if (!$result) {
        throw new Exception('Error while saving database, please try again.');
    }
    return true;
}


//Verify user information function at login
function login($username, $password) {
    $conn = db_connect();
    $result = $conn->query("select * from user where username='".$username."' and passwd = sha1('".$password."')");
    if (!$result) {
        throw new Exception('Wrong account or password, please re-enter.');
    }
    if ($result->num_rows>0) {
        return true;
    } else {
        throw new Exception('Wrong account or password, please re-enter.');
    }
}

//Check user session information functions
function check_valid_user() {
    if (isset($_SESSION['valid_user']))  {
        echo "<header class='site-head'><div class='center-wrap'><a href='logout.php'class='loginbutton'>Logout</a><a href='change_passwd_form.php' class='register'>Welcome:".$_SESSION['valid_user']."</a></div></header>";
    } else {
        echo '<h1>Problem !</h1>';
        echo 'You are not logged in.<br />';
        do_html_url('login.php', 'Re-longin');
        do_html_footer();
        exit;
    }
}


//A function that updates the changed password to the database
function change_password($username, $old_password, $new_password) {
    login($username, $old_password);
    $conn = db_connect();
    $result = $conn->query("update user set passwd = sha1('".$new_password."')where username = '".$username."'");
    if (!$result) {
        throw new Exception('Password change error.');
    } else {
        return true;
    }
}


?>
