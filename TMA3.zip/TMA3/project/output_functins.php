<?php
// A function that outputs the header title
function do_html_header($title)
{
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Online Fresh Food</title>
        <link rel="stylesheet" href="css/reset.css">
        <link rel="stylesheet" href="css/base.css">
        <link rel="stylesheet" href="css/css.css">

    </head>

<?php
}

function display_body()
{

?>

    <body>

        <section class="navigation">
            <div class="center-wrap">
                <h1 class="logo">
                    Fresh Food
                </h1>
                <ul>
                    <li>
                        <a href="">
                            <img src="Images/home-gry.png" alt="">
                            <img src="Images/home-white.png" alt="">
                            <span>Home Page</span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <img src="Images/abouts-gry.png" alt="">
                            <img src="Images/abouts-white.png" alt="">
                            <span>About us</span>
                        </a>
                    </li>
                    <li>
                        <a href="return.php">
                            <img src="Images/kefu-gry.png" alt="">
                            <img src="Images/kefu-white.png" alt="">
                            <span>Return</span>
                        </a>
                    </li>
                    <li>
                        <a href="hot.php">
                            <img src="Images/chanpin-gry.png" alt="">
                            <img src="Images/chanpin-white.png" alt="">
                            <span>Hot Product</span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <img src="Images/fuwu-gry.png" alt="">
                            <img src="Images/fuwu-white.png" alt="">
                            <span>On Sale</span>
                        </a>
                    </li>
                </ul>
                <div class="search-bar">
                    <input type="text" placeholder="search for">
                    <button><img src="images/search.png" alt=""></button>
                </div>
            </div>
        </section>

        <!-- Banner of the site -->
        <section id="banner" class="banner">
            <div class="box">
                <ul id="list1">
                    <li><img src="./Images/banner01.jpg"></li>
                    <li><img src="./Images/banner02.jpg"></li>
                    <li><img src="./Images/banner03.jpg"></li>

                </ul>
                <ol id="list2">
                </ol>
                <div id="btn">
                    <div class="btnLeft btn">&lt;</div>
                    <div class="btnRight btn">&gt;</div>
                </div>
            </div>
        </section>

        <!-- Product of the site -->
        <section class="product">
            <div class="center-wrap">
                <div class="button">
                    <a href="javascript:;" id="prevbtn" class="prevbtn">
                        <img src="Images/prev.png" alt="">
                    </a>
                    <a href="javascript:;" id="nextbtn" class="nextbtn">
                        <img src="Images/next.png" alt="">
                    </a>
                </div>
                <div class="products">
                    <ul id="productCarousel">
                        <li>
                            <a href="">
                                <img src="Images/product01.jpg" alt="">
                                <span>Fresh mutton 2029</span>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <img src="Images/product02.jpg" alt="">
                                <span>Fresh seafood 2029</span>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <img src="Images/product03.jpg" alt="">
                                <span>Fresh Beef 2029</span>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <img src="Images/product04.jpg" alt="">
                                <span>Fresh shellfish 2029</span>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <img src="Images/product05.jpg" alt="">
                                <span>Fresh shellfish 2029</span>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <img src="Images/product06.jpg" alt="">
                                <span>Fresh bamboo 2029</span>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <img src="Images/product07.jpg" alt="">
                                <span>Fresh squid 2029</span>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <img src="Images/product08.jpg" alt="">
                                <span>Fresh squid 2029</span>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <img src="Images/product09.jpg" alt="">
                                <span>Fresh Lobster 2029</span>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <img src="Images/product10.jpg" alt="">
                                <span>Fresh Prawns 2029</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </section>

        <section class="about-us">
            <div class="center-wrap">
                <div class="text-area">
                    <span>About Us</span>
                    <span>about us</span>
                    <div></div>
                </div>
                <div class="info-pics">
                    <div class="info">
                        <a href="" class="subtitle">
                            <h3>About us</h3>
                        </a>
                        <a href="" class="comp-name">
                            <p>Fresh Food Ltd.</p>
                        </a>
                        <div class="dividerline"></div>
                        <a href="" class="description">
                            <p>Online fresh food is to provide you with the fresh products one-stop online shopping experience…</p>
                        </a>
                        <a href="" class="knowingmore">
                            <span>Learn more</span>
                        </a>
                    </div>
                    <div class="pics">
                        <a href="">
                            <img src="Images/aboutus.png" alt="">
                        </a>
                    </div>
                    <div class="services">
                        <ul>
                            <li>
                                <a href="">
                                    <img src="Images/liuyan.png" alt="">
                                    <span>Live Agent</span>
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <img src="images/guanggao.png" alt="">
                                    <span>Advertising management</span>
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <img src="images/wangluo.png" alt="">
                                    <span>Network consultation</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <section class="press-center">
            <div class="center-wrap">
                <div class="text-area">
                    <span>Food Recipes</span>
                    <span>Recettes de cuisine</span>
                    <div></div>
                </div>
                <div class="info-area">
                    <ul>
                        <li>
                            <a href="">
                                <span>01</span>
                                <span>Homemade Cannoli</span>
                                <span>Italian bakeries have been serving up cannoli forever. The crispy shell and creamy sweet filling are nearly irresistible……</span>
                            </a>
                        </li>
                    </ul>
                    <ul>
                        <li>
                            <a href="">
                                <span>02</span>
                                <span>Mummy Hot Dogs</span>
                                <span>There are a lot of mummy hot dogs in the world, but ours is the best for a couple of big reasons……</span>
                            </a>
                        </li>
                    </ul>
                    <ul>
                        <li>
                            <a href="">
                                <span>03</span>
                                <span>Pumpkin Ravioli</span>
                                <span>After buying a house, whether it is a rough room or left second-hand housing,
                                    many owners will choose to decorate……</span>
                            </a>
                        </li>
                    </ul>
                    <ul>
                        <li>
                            <a href="">
                                <span>04</span>
                                <span>Butter chicken</span>
                                <span>The chicken can be marinaded the day before so you can get ahead on your prep……</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <section class="contactinfo">
            <div class="center-wrap">
                <h2 class="logo">Fresh Food</h2>
                <div>
                    <span>Telephone：647-000-0000</span>
                    <span>Website：www.1234.com</span>
                    <span>E-mail：info@1234.com</span>
                </div>
            </div>
        </section>

        <!-- back to top -->
        <a href="javascript:;" id="backtotop" class="backtotop">Back to Top</a>

        <!-- Customer Service -->
        <section>
            <div class="feedback">
                <h3 class="feedbackHeader eMailIco">
                    Please leave us a message
                </h3>
                <span class="closeBtn"></span>
                <form class="feedbackForm" action="">
                    <p class="tips">Please fill in your email address and we will reply to your ASAP</p>
                    <div class="line">
                        <textarea name="" placeholder="*Please fill in the message"></textarea>
                    </div>
                    <div class="line">
                        <input type="text" name="" placeholder="Please fill in your name">
                    </div>
                    <div class="line">
                        <input type="text" name="" placeholder="*Please fill in the email">
                    </div>
                    <input class="btn" type="submit" value="Submit">
                </form>
            </div>
        </section>

        <script src="./js/jquery-3.4.1.min.js"></script>
        <script src="./js/banner.js"></script>
        <script src="./js/fedback.js"></script>
        <script src="./js/backtotop.js"></script>
        <script src="./js/productcarousel.js"></script>
        <script src="./js/recommcarousel.js"></script>
    </body>

    </html>

<?php
}

// The function to jump to the page
function do_html_URL($url, $name)
{
?>
    <br>
    <br /><a href="<?php echo $url; ?>"><?php echo $name; ?></a><br />
<?php
}

function display_footer()
{
?>
    <footer>
        <div class="center-wrap">
            <span>Copyright © 2022 1234.com All Rights Reserved</span>
        </div>
    </footer>
<?php
}
?>