<?php

//Import function library
require_once('bm_functions.php');
session_start();

//After a successful longin
do_html_header("RETURN");
//Verify session registration information
check_valid_user();
?>

    <section class="navigation">
        <div class="center-wrap">
            <h1 class="logo">
                Fresh Food
            </h1>
            <ul>
                <li>
                    <a href="member.php">
                        <img src="Images/home-gry.png" alt="">
                        <img src="Images/home-white.png" alt="">
                        <span>Home Page</span>
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="Images/abouts-gry.png" alt="">
                        <img src="Images/abouts-white.png" alt="">
                        <span>About us</span>
                    </a>
                </li>
                <li>
                    <a href="return.php">
                        <img src="Images/kefu-gry.png" alt="">
                        <img src="Images/kefu-white.png" alt="">
                        <span>Return</span>
                    </a>
                </li>
                <li>
                    <a href="hot.php">
                        <img src="Images/chanpin-gry.png" alt="">
                        <img src="Images/chanpin-white.png" alt="">
                        <span>Hot Product</span>
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="Images/fuwu-gry.png" alt="">
                        <img src="Images/fuwu-white.png" alt="">
                        <span>On Sale</span>
                    </a>
                </li>
            </ul>
            <div class="search-bar">
                <input type="text" placeholder="search for">
                <button><img src="images/search.png" alt=""></button>
            </div>
        </div>
    </section>

    <section class="return">
        <h2>Return Policy</h2>
        <p>
            If you are not satisfied with any product, please contact our customer service at the "please leave us a message" area below. Our service staff will pick it up at the appointed time and refund it within the next 24 hours................
        </p>

    </section>
    
    <footer>
        <div class="center-wrap">
            <span>Copyright © 2021 1234.com All Rights Reserved</span>
        </div>
    </footer>

    <!-- back to top -->
    <a href="javascript:;" id="backtotop" class="backtotop">Back to Top</a>

    <!-- Customer Service -->
    <section>
        <div class="feedback">
            <h3 class="feedbackHeader eMailIco">
                Please leave us a message
            </h3>
            <span class="closeBtn"></span>
            <form class="feedbackForm" action="">
                <p class="tips">Please fill in your email address and we will reply to your ASAP</p>
                <div class="line">
                    <textarea name="" placeholder="*Please fill in the message"></textarea>
                </div>
                <div class="line">
                    <input type="text" name="" placeholder="Please fill in your name">
                </div>
                <div class="line">
                    <input type="text" name="" placeholder="*Please fill in the email">
                </div>
                <input class="btn" type="submit" value="Submit">
            </form>
        </div>
    </section>

    <script src="./js/jquery-3.4.1.min.js"></script>
    <script src="./js/login.js"></script>
    <script src="./js/banner.js"></script>
    <script src="./js/fedback.js"></script>
    <script src="./js/backtotop.js"></script>
    <script src="./js/productcarousel.js"></script>
    <script src="./js/recommcarousel.js"></script>