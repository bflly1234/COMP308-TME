<?php
 //Import a custom function library
  require_once('bm_functions.php');

  $email=$_POST['email'];
  $username=$_POST['username'];
  $passwd=$_POST['passwd'];
  $passwd2=$_POST['passwd2'];
  // Open session
  session_start();
  try   {
    // Call the function to check that the form is filled in
      if (!filled_out($_POST)) {
      throw new Exception('Your form is not completed, please continue to fill in!');
      }
      //Filtering User names
      if(!preg_match("/^[\x{4e00}-\x{9fa5}A-Za-z0-9_]{6,16}+$/u",$username)){
          throw new Exception('User name contains invalid characters or length error, please re-enter!');
      }

      // Filtering the password
      if ($passwd !== $passwd2) {
          throw new Exception('The password entered twice is inconsistent, please input again!');
      }
      if(!preg_match("/^[A-Za-z0-9_]{6,16}+$/u",$passwd)){
          throw new Exception('Password contains invalid characters or length error, please re-enter!');
      }
      if(!preg_match("/^[A-Za-z0-9_]{6,16}+$/u",$passwd2)){
          throw new Exception('Password contains invalid characters or length error, please re-enter!');
      }
      // Filtering mail addresses
      if (!valid_email($email)) {
      throw new Exception('This is not a valid email address, please fill it out again!');
      }

      // Call a custom function to insert registration information into the database
      register($username, $email, $passwd);
      // Saves user session information
      $_SESSION['valid_user'] = $username;


      do_html_header('Registration successful');
      echo 'Registration successful!';
      do_html_url('login.php', 'Re-login');


  }
  catch (Exception $e) {
     do_html_header('Problem:');
     echo $e->getMessage();
     do_html_footer();
     exit;
  }
?>
